document.addEventListener('DOMContentLoaded', () => {
    const stars = document.querySelector('.stars');
    const characters = document.querySelectorAll('.girl, .boy');

    setInterval(() => {
        stars.style.backgroundPosition = `${Math.random() * 100}px ${Math.random() * 100}px`;
    }, 2000);

    characters.forEach(char => {
        char.style.animation = 'bounce 4s infinite';
    });
});

const style = document.createElement('style');
style.innerHTML = `
    @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
`;
document.head.appendChild(style);
